public class Select extends javax.swing.JFrame {

    protected int selectedR = 0; 
    protected int selectedL = 0;
    
    public Select() {
        initComponents();
        
        Locker2.setVisible(false);
        Locker3.setVisible(false);
        Locker4.setVisible(false);
        Locker1.setVisible(false);
        Player2Text.setVisible(false);
        FightButton.setVisible(false);
        
        
    }
    
    
    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        FightButton = new javax.swing.JButton();
        Player2Text = new javax.swing.JLabel();
        Player1Text = new javax.swing.JLabel();
        Locker1 = new javax.swing.JLabel();
        Locker2 = new javax.swing.JLabel();
        Locker3 = new javax.swing.JLabel();
        Locker4 = new javax.swing.JLabel();
        Locker5 = new javax.swing.JLabel();
        Locker6 = new javax.swing.JLabel();
        Locker7 = new javax.swing.JLabel();
        Locker8 = new javax.swing.JLabel();
        PlayerSistemasR = new javax.swing.JButton();
        PlayerProfeR = new javax.swing.JButton();
        PlayerDiegoR = new javax.swing.JButton();
        PlayerArquiR = new javax.swing.JButton();
        PlayerSistemasL = new javax.swing.JButton();
        PlayerArquiL = new javax.swing.JButton();
        PlayerProfeL = new javax.swing.JButton();
        PlayerDiegoL = new javax.swing.JButton();
        Fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Funny Fight");
        setMaximumSize(new java.awt.Dimension(1280, 720));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        FightButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Fight.png"))); // NOI18N
        FightButton.setContentAreaFilled(false);
        FightButton.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        FightButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FightButtonActionPerformed(evt);
            }
        });
        getContentPane().add(FightButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 480, 320, 110));

        Player2Text.setFont(new java.awt.Font("ArcadeClassic", 0, 48)); // NOI18N
        Player2Text.setForeground(new java.awt.Color(255, 255, 255));
        Player2Text.setText("PLAYER 2");
        getContentPane().add(Player2Text, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 110, -1, -1));

        Player1Text.setFont(new java.awt.Font("ArcadeClassic", 0, 48)); // NOI18N
        Player1Text.setForeground(new java.awt.Color(255, 255, 255));
        Player1Text.setText("PLAYER 1");
        getContentPane().add(Player1Text, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 110, -1, -1));

        Locker1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Locker.png"))); // NOI18N
        Locker1.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(Locker1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, -1, -1));

        Locker2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Locker.png"))); // NOI18N
        Locker2.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(Locker2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 140, -1, -1));

        Locker3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Locker.png"))); // NOI18N
        Locker3.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(Locker3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 430, -1, -1));

        Locker4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Locker.png"))); // NOI18N
        Locker4.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(Locker4, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 430, -1, -1));

        Locker5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Locker.png"))); // NOI18N
        Locker5.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(Locker5, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 140, -1, -1));

        Locker6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Locker.png"))); // NOI18N
        Locker6.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(Locker6, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 140, -1, -1));

        Locker7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Locker.png"))); // NOI18N
        Locker7.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(Locker7, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 420, -1, -1));

        Locker8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Locker.png"))); // NOI18N
        Locker8.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(Locker8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 430, -1, -1));

        PlayerSistemasR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer1R.png"))); // NOI18N
        PlayerSistemasR.setBorderPainted(false);
        PlayerSistemasR.setContentAreaFilled(false);
        PlayerSistemasR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlayerSistemasRActionPerformed(evt);
            }
        });
        getContentPane().add(PlayerSistemasR, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, 190, 170));

        PlayerProfeR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer3R.png"))); // NOI18N
        PlayerProfeR.setContentAreaFilled(false);
        PlayerProfeR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlayerProfeRActionPerformed(evt);
            }
        });
        getContentPane().add(PlayerProfeR, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 510, 190, 170));

        PlayerDiegoR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer5R.png"))); // NOI18N
        PlayerDiegoR.setContentAreaFilled(false);
        PlayerDiegoR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlayerDiegoRActionPerformed(evt);
            }
        });
        getContentPane().add(PlayerDiegoR, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 510, 190, 170));

        PlayerArquiR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer2R.png"))); // NOI18N
        PlayerArquiR.setContentAreaFilled(false);
        PlayerArquiR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlayerArquiRActionPerformed(evt);
            }
        });
        getContentPane().add(PlayerArquiR, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 230, 180, 170));

        PlayerSistemasL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer1L.png"))); // NOI18N
        PlayerSistemasL.setToolTipText("");
        PlayerSistemasL.setContentAreaFilled(false);
        PlayerSistemasL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlayerSistemasLActionPerformed(evt);
            }
        });
        getContentPane().add(PlayerSistemasL, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 230, 190, 170));

        PlayerArquiL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer2L.png"))); // NOI18N
        PlayerArquiL.setContentAreaFilled(false);
        PlayerArquiL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlayerArquiLActionPerformed(evt);
            }
        });
        getContentPane().add(PlayerArquiL, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 230, 170, 170));

        PlayerProfeL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer3L.png"))); // NOI18N
        PlayerProfeL.setContentAreaFilled(false);
        PlayerProfeL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlayerProfeLActionPerformed(evt);
            }
        });
        getContentPane().add(PlayerProfeL, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 510, 170, 170));

        PlayerDiegoL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer5L.png"))); // NOI18N
        PlayerDiegoL.setContentAreaFilled(false);
        PlayerDiegoL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlayerDiegoLActionPerformed(evt);
            }
        });
        getContentPane().add(PlayerDiegoL, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 510, 190, 170));

        Fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/BackSeelectFinal.png"))); // NOI18N
        getContentPane().add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //Zona de botones    
    private void PlayerSistemasRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlayerSistemasRActionPerformed
        Locker2.setVisible(true);
        Locker3.setVisible(true);
        Locker4.setVisible(true);
        PlayerArquiR.setVisible(false);
        PlayerDiegoR.setVisible(false);
        PlayerProfeR.setVisible(false);
        Player1Text.setVisible(false);
        
        Locker5.setVisible(false);
        Locker6.setVisible(false);
        Locker7.setVisible(false);
        Locker8.setVisible(false);
        Player2Text.setVisible(true);
        
        selectedL = 1;
        

    }//GEN-LAST:event_PlayerSistemasRActionPerformed

    private void PlayerProfeRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlayerProfeRActionPerformed
        Locker1.setVisible(true);
        Locker2.setVisible(true);
        Locker4.setVisible(true);
        PlayerArquiR.setVisible(false);
        PlayerDiegoR.setVisible(false);
        PlayerSistemasR.setVisible(false);
        Player1Text.setVisible(false);
        
        Locker5.setVisible(false);
        Locker6.setVisible(false);
        Locker7.setVisible(false);
        Locker8.setVisible(false);
        Player2Text.setVisible(true);
        

        
        selectedL = 3;
    }//GEN-LAST:event_PlayerProfeRActionPerformed

    private void PlayerDiegoRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlayerDiegoRActionPerformed
        Locker1.setVisible(true);
        Locker2.setVisible(true);
        Locker3.setVisible(true);
        PlayerArquiR.setVisible(false);
        PlayerSistemasR.setVisible(false);
        PlayerProfeR.setVisible(false);
        Player1Text.setVisible(false);
        
        Locker5.setVisible(false);
        Locker6.setVisible(false);
        Locker7.setVisible(false);
        Locker8.setVisible(false);
        Player2Text.setVisible(true);
        
        
        selectedL = 4;
    }//GEN-LAST:event_PlayerDiegoRActionPerformed

    private void PlayerArquiRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlayerArquiRActionPerformed
        Locker1.setVisible(true);
        Locker3.setVisible(true);
        Locker4.setVisible(true);
        PlayerSistemasR.setVisible(false);
        PlayerDiegoR.setVisible(false);
        PlayerProfeR.setVisible(false);
        Player1Text.setVisible(false);
        
        Locker5.setVisible(false);
        Locker6.setVisible(false);
        Locker7.setVisible(false);
        Locker8.setVisible(false);
        Player2Text.setVisible(true);
        
        
        selectedL = 2;
    }//GEN-LAST:event_PlayerArquiRActionPerformed

    private void PlayerSistemasLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlayerSistemasLActionPerformed
        Locker6.setVisible(true);
        Locker7.setVisible(true);
        Locker8.setVisible(true);
        PlayerArquiL.setVisible(false);
        PlayerDiegoL.setVisible(false);
        PlayerProfeL.setVisible(false);
        FightButton.setVisible(true);
        

        
        selectedR = 5;
        
    }//GEN-LAST:event_PlayerSistemasLActionPerformed

    private void PlayerArquiLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlayerArquiLActionPerformed
        Locker5.setVisible(true);
        Locker7.setVisible(true);
        Locker8.setVisible(true);
        PlayerSistemasL.setVisible(false);
        PlayerDiegoL.setVisible(false);
        PlayerProfeL.setVisible(false);
        FightButton.setVisible(true);
        

        
        selectedR = 6;
    }//GEN-LAST:event_PlayerArquiLActionPerformed

    private void PlayerProfeLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlayerProfeLActionPerformed
        Locker5.setVisible(true);
        Locker6.setVisible(true);
        Locker8.setVisible(true);
        PlayerArquiL.setVisible(false);
        PlayerDiegoL.setVisible(false);
        PlayerSistemasL.setVisible(false);
        FightButton.setVisible(true);
        

        
        selectedR = 7;
        
    }//GEN-LAST:event_PlayerProfeLActionPerformed

    private void PlayerDiegoLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlayerDiegoLActionPerformed
        Locker5.setVisible(true);
        Locker6.setVisible(true);
        Locker7.setVisible(true);
        PlayerArquiL.setVisible(false);
        PlayerSistemasL.setVisible(false);
        PlayerProfeL.setVisible(false);
        FightButton.setVisible(true);
        

        
        selectedR = 8;
        
    }//GEN-LAST:event_PlayerDiegoLActionPerformed

    private void FightButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FightButtonActionPerformed
       SelectPoke selectP = new SelectPoke(selectedR, selectedL);
       selectP.setVisible(true);
       this.dispose();
    }//GEN-LAST:event_FightButtonActionPerformed

    
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Select.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Select.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Select.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Select.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Select().setVisible(true);
          
            }
        });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton FightButton;
    private javax.swing.JLabel Fondo;
    private javax.swing.JLabel Locker1;
    private javax.swing.JLabel Locker2;
    private javax.swing.JLabel Locker3;
    private javax.swing.JLabel Locker4;
    private javax.swing.JLabel Locker5;
    private javax.swing.JLabel Locker6;
    private javax.swing.JLabel Locker7;
    private javax.swing.JLabel Locker8;
    private javax.swing.JLabel Player1Text;
    private javax.swing.JLabel Player2Text;
    private javax.swing.JButton PlayerArquiL;
    private javax.swing.JButton PlayerArquiR;
    private javax.swing.JButton PlayerDiegoL;
    private javax.swing.JButton PlayerDiegoR;
    private javax.swing.JButton PlayerProfeL;
    private javax.swing.JButton PlayerProfeR;
    private javax.swing.JButton PlayerSistemasL;
    private javax.swing.JButton PlayerSistemasR;
    // End of variables declaration//GEN-END:variables
    
    
}


