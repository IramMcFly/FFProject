public interface Luchador {
    
    int atacar();
    int curar();
    
}
