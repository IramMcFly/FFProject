public class Player implements Luchador{
    
    private double potenciador;
    private String personaje;
    private Pokemon pokemon;
    
    public Player() {
        this.potenciador = 0;
        this.personaje = "-----";
    }

    public double getPotenciador() {
        return potenciador;
    }

    public void setPotenciador(double potenciador) {
        this.potenciador = potenciador;
    }

    public String getPersonaje() {
        return personaje;
    }

    public void setPersonaje(String personaje) {
        this.personaje = personaje;
    }

    public String getPokemon() {
        return pokemon.getNombre();
    }

    public void setPokemon(Pokemon pokemon) {
        this.pokemon = pokemon;
    }

    @Override
    public int atacar() {
        double ataqueD = ((Math.random()*15) + 10) * potenciador;
        int ataqueP = (int)ataqueD; //transformamos el double a int para bajarselo a la barra del p2
        return ataqueP;
    }

    @Override
    public int curar() {
        return 15;
    }

    
    
 
}
