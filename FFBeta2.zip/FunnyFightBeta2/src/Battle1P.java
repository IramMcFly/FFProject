
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.util.concurrent.Executors;

public class Battle1P extends javax.swing.JFrame {

    private int Izquierda = 0; // Contador para los botónes de la izquierda
    private int Derecha = 0; // Contador para los botónes de la derecha
    private boolean winner = false;
            
    Player player1 = new Player();
    Player player2 = new Player();
        
    Pokemon pok1 = new Pokemon(0, "", "2", 0);
    Pokemon pok2 = new Pokemon(0, "", "2", 0);
    
    private int e1 = 0;
    private int e2 = 0;
    private int p1 = 0;
    private int p2 = 0;
    

    public Battle1P(int e1,int p1, int e2, int p2) { //e = entrenador p=pokemon
        
        initComponents();
        
        this.e2 = e2;
        this.e1 = e1;
        this.p2 = p2;
        this.p1 = p1;
        
        E1.setVisible(false);
        E2.setVisible(false);
        E3.setVisible(false);
        E4.setVisible(false);
        P1.setVisible(false);
        P2.setVisible(false);
        P3.setVisible(false);
        
        E5.setVisible(false);
        E6.setVisible(false);
        E7.setVisible(false);
        E8.setVisible(false);
        P4.setVisible(false);
        P5.setVisible(false);
        P6.setVisible(false);
                
        Turno.setText("Player 1 Turn!");

              
        
        switch (e1){
            
            case 1:
                player1.setPersonaje("Sistemas");
                player1.setPotenciador(1.5);
            break;
            
            case 2: 
                player1.setPersonaje("Arqui");
                player1.setPotenciador(1.2);
            break;
            
            case 3:
                player1.setPersonaje("Profe");
                player1.setPotenciador(2.4);
            break;
            
            case 4:
                player1.setPersonaje("Rosa");
                player1.setPotenciador(1.1);
            break;
        
        }
        
        switch (e2){
            
            case 1:
                player2.setPersonaje("Rosa");
                player2.setPotenciador(1.1);
            break;
            
            case 2: 
                player2.setPersonaje("Arqui");
                player2.setPotenciador(1.2);
            break;
            
            case 3:
                player2.setPersonaje("Sistemas");
                player2.setPotenciador(1.5);
            break;
            
            
            case 4:
                player2.setPersonaje("Profe");
                player2.setPotenciador(2.4);
            break;

        
        }
        
        
        
        switch (p1) {
            case 1:
                pok1.setNombre("Inge");
                pok1.setVida(120);
                Barra1.setMaximum(pok1.getVida());
                Barra1.setMinimum(0);
                Barra1.setValue(pok1.getVida());
                HealPercent1.setText((Barra1.getPercentComplete())*100 + "%");
            break;
            
            case 2:
                pok1.setNombre("Licenciada");
                pok1.setVida(100);
                Barra1.setMaximum(pok1.getVida());
                Barra1.setMinimum(0);
                Barra1.setValue(pok1.getVida());
                HealPercent1.setText((Barra1.getPercentComplete())*100 + "%");
            break;
            
            case 3:
                pok1.setNombre("Bisonte");
                pok1.setVida(150);
                Barra1.setMaximum(pok1.getVida());
                Barra1.setMinimum(0);
                Barra1.setValue(pok1.getVida());
                HealPercent1.setText((Barra1.getPercentComplete())*100 + "%");
            break;
        }
        
        switch (p2) {
            case 1:
                pok2.setNombre("Licenciada");
                pok2.setVida(100);
                Barra2.setMaximum(pok2.getVida());
                Barra2.setMinimum(0);
                Barra2.setValue(pok2.getVida());
                HealPercent2.setText((Barra2.getPercentComplete())*100 + "%");
            break;
            
            case 2:
                pok2.setNombre("Inge");
                pok2.setVida(120);
                Barra2.setMaximum(pok2.getVida());
                Barra2.setMinimum(0);
                Barra2.setValue(pok2.getVida());
                HealPercent2.setText((Barra2.getPercentComplete())*100 + "%");
            break;
            
            case 3:
                pok2.setNombre("Bisonte");
                pok2.setVida(150);
                Barra2.setMaximum(pok2.getVida());
                Barra2.setMinimum(0);
                Barra2.setValue(pok2.getVida());
                HealPercent2.setText((Barra2.getPercentComplete())*100 + "%");
            break;
            
            case 4:
                pok2.setNombre("Bisonte");
                pok2.setVida(150);
                Barra2.setMaximum(pok2.getVida());
                Barra2.setMinimum(0);
                Barra2.setValue(pok2.getVida());
                HealPercent2.setText((Barra2.getPercentComplete())*100 + "%");
            break;
        }
        
        player1.setPokemon(pok1);
        player2.setPokemon(pok2);
        
        switch (player1.getPersonaje()) {
            case "Sistemas":
                E1.setVisible(true);
            break;
            
            case "Arqui":
                E2.setVisible(true);
            break;
            
            case "Profe":
                E3.setVisible(true);
            break;
                
            case "Rosa":
                E4.setVisible(true);
            break;

        }
        
        switch (player2.getPersonaje()) {
            case "Sistemas":
                E5.setVisible(true);
            break;
            
            case "Arqui":
                E6.setVisible(true);
            break;
            
            case "Profe":
                E7.setVisible(true);
            break;
                
            case "Rosa":
                E8.setVisible(true);
            break;

        }
        
        
        
        switch (player1.getPokemon()) {
            case "Inge":
                P1.setVisible(true);
            break;
            
            case "Licenciada":
                P2.setVisible(true);
            break;
            
            case "Bisonte":
                P3.setVisible(true);
            break;
        }
        
        switch (player2.getPokemon()) {
            case "Inge":
                P4.setVisible(true);
            break;
            
            case "Licenciada":
                P5.setVisible(true);
            break;
            
            case "Bisonte":
                P6.setVisible(true);
            break;
        }
        
    }
  
    public int bar1Status() {
        double bar = Barra1.getPercentComplete();
        bar *= 100;
        return (int)bar;
    }
    public int bar2Status() {
        double bar = Barra2.getPercentComplete();
        bar = (bar * 100);
        return (int)bar;
    }
    
    public Battle1P() {
        initComponents();
    }

    
    void getWinner(){
        int winnerN = 0;
        
        if(pok1.getVida() > pok2.getVida()){
            winnerN = 1;
            WinnerScreen win = new WinnerScreen(e1, e2, p1, p2, winnerN);
            win.setVisible(true);
            this.dispose();
        }
        if(pok2.getVida() > pok1.getVida()){
            winnerN = 2;
            WinnerScreen win = new WinnerScreen(e1, e2, p1, p2, winnerN);
            win.setVisible(true);
            this.dispose();
        }
                
        
    }

    private void callAI(){
        int Selecter = (int) ((Math.random()*2) + 1);
        
        if(Selecter == 1){
           //ai ataca
            AIAtack();
        }else{
            AIHeal();
        }
            
    }
    
private void AIAtack(){
    if(Derecha < 10 &&  pok1.getVida() >= 0){
            Derecha++;

            pok1.setVida(-1 * player2.atacar());
            Barra1.setValue(pok1.getVida());
            HealPercent1.setText(bar1Status() + "%");

            if(pok1.getVida() <= 0){
                getWinner();
            }

            AtackL.setVisible(true);
            HealL.setVisible(true);
           
            Turno.setText("Player 1 Turn!");
        }else{
            getWinner();
        }
}
    
    private void AIHeal(){
    
        if(Derecha < 10 && pok2.getVida() >= 0){
            Derecha++;

            pok2.setVida(player2.curar());
            Barra2.setValue(pok2.getVida());

            HealPercent2.setText(bar2Status() + "%");

            AtackL.setVisible(true);
            HealL.setVisible(true);
            
            Turno.setText("Player 1 Turn!");
        }else{
            getWinner();
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Play1Txt = new javax.swing.JLabel();
        Play2Txt = new javax.swing.JLabel();
        HealPercent1 = new javax.swing.JLabel();
        HealPercent2 = new javax.swing.JLabel();
        Barra1 = new javax.swing.JProgressBar();
        Barra2 = new javax.swing.JProgressBar();
        E1 = new javax.swing.JLabel();
        E2 = new javax.swing.JLabel();
        E3 = new javax.swing.JLabel();
        E4 = new javax.swing.JLabel();
        E5 = new javax.swing.JLabel();
        E6 = new javax.swing.JLabel();
        E7 = new javax.swing.JLabel();
        E8 = new javax.swing.JLabel();
        P1 = new javax.swing.JLabel();
        P2 = new javax.swing.JLabel();
        P3 = new javax.swing.JLabel();
        P4 = new javax.swing.JLabel();
        P5 = new javax.swing.JLabel();
        P6 = new javax.swing.JLabel();
        HealL = new javax.swing.JButton();
        AtackL = new javax.swing.JButton();
        Turno = new javax.swing.JLabel();
        Fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Funny Fight");
        setResizable(false);
        setSize(new java.awt.Dimension(1280, 720));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Play1Txt.setFont(new java.awt.Font("ArcadeClassic", 0, 48)); // NOI18N
        Play1Txt.setForeground(new java.awt.Color(255, 255, 255));
        Play1Txt.setText("PLAYER 1");
        getContentPane().add(Play1Txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 200, -1));

        Play2Txt.setFont(new java.awt.Font("ArcadeClassic", 0, 48)); // NOI18N
        Play2Txt.setForeground(new java.awt.Color(255, 255, 255));
        Play2Txt.setText("PLAYER 2");
        getContentPane().add(Play2Txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 0, 200, -1));

        HealPercent1.setFont(new java.awt.Font("Super Mario Bros. 2", 0, 36)); // NOI18N
        HealPercent1.setForeground(new java.awt.Color(255, 255, 255));
        HealPercent1.setText("0%");
        getContentPane().add(HealPercent1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 40, -1, -1));

        HealPercent2.setFont(new java.awt.Font("Super Mario Bros. 2", 0, 36)); // NOI18N
        HealPercent2.setForeground(new java.awt.Color(255, 255, 255));
        HealPercent2.setText("0%");
        getContentPane().add(HealPercent2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 40, -1, -1));

        Barra1.setBackground(new java.awt.Color(255, 255, 255));
        Barra1.setForeground(new java.awt.Color(255, 0, 0));
        Barra1.setMaximum(150);
        getContentPane().add(Barra1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 290, 20));

        Barra2.setBackground(new java.awt.Color(255, 255, 255));
        Barra2.setForeground(new java.awt.Color(0, 0, 204));
        getContentPane().add(Barra2, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 50, 290, 20));

        E1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer1R.png"))); // NOI18N
        E1.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(E1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-80, 250, -1, -1));

        E2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer2R.png"))); // NOI18N
        E2.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(E2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-50, 240, -1, -1));

        E3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer3R.png"))); // NOI18N
        E3.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(E3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-80, 250, -1, -1));

        E4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer5R.png"))); // NOI18N
        E4.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(E4, new org.netbeans.lib.awtextra.AbsoluteConstraints(-70, 250, -1, -1));

        E5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer1L.png"))); // NOI18N
        E5.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(E5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 260, 240, -1));

        E6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer2L.png"))); // NOI18N
        E6.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(E6, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 260, 260, -1));

        E7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer3L.png"))); // NOI18N
        E7.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(E7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 250, 240, -1));

        E8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Trainer5L.png"))); // NOI18N
        E8.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(E8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 260, 260, -1));

        P1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/IngeR.png"))); // NOI18N
        P1.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(P1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 270, -1, -1));

        P2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/LirR.png"))); // NOI18N
        P2.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(P2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 250, -1, -1));

        P3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/BisR.png"))); // NOI18N
        getContentPane().add(P3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 260, -1, -1));

        P4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/IngeL.png"))); // NOI18N
        P4.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(P4, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 280, -1, -1));

        P5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/LirL.png"))); // NOI18N
        P5.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(P5, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 260, -1, -1));

        P6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/BisL.png"))); // NOI18N
        P6.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        getContentPane().add(P6, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 270, -1, -1));

        HealL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Healt.png"))); // NOI18N
        HealL.setContentAreaFilled(false);
        HealL.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        HealL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                HealLMouseReleased(evt);
            }
        });
        getContentPane().add(HealL, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 610, 140, 80));

        AtackL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Atack.png"))); // NOI18N
        AtackL.setContentAreaFilled(false);
        AtackL.setDisabledIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/Nothing.png"))); // NOI18N
        AtackL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                AtackLMouseReleased(evt);
            }
        });
        getContentPane().add(AtackL, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 610, -1, 80));

        Turno.setFont(new java.awt.Font("ArcadeClassic", 0, 48)); // NOI18N
        Turno.setForeground(new java.awt.Color(255, 255, 255));
        Turno.setText("PLAYER 1 TURN!");
        getContentPane().add(Turno, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 640, -1, -1));

        Fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sprites/FondoMainMenu.png"))); // NOI18N
        getContentPane().add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    
    
    private void AtackLMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AtackLMouseReleased

         if(Izquierda < 10  &&  pok2.getVida() >= 0){

            Izquierda++;


            pok2.setVida(-1 * player1.atacar());
            Barra2.setValue(pok2.getVida());
            HealPercent2.setText(bar2Status() + "%");
            
            if(pok2.getVida() <= 0){
                getWinner();
            }
            
            AtackL.setVisible(false);
            HealL.setVisible(false);
            
            callAI();
            
             
           
        }else{
             getWinner();
        }
    }//GEN-LAST:event_AtackLMouseReleased

    private void HealLMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HealLMouseReleased

        if(Izquierda < 10 && pok1.getVida() >= 0){
            Izquierda++;
            
            pok1.setVida(player1.curar());
            Barra1.setValue(pok1.getVida());
            HealPercent1.setText(bar1Status() + "%");
            
            AtackL.setVisible(false);
            HealL.setVisible(false);
            
            callAI();

            
        }else{
            getWinner();
        }
    }//GEN-LAST:event_HealLMouseReleased
/*
    */
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Battle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Battle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Battle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Battle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Battle(1,1,1,1).setVisible(true);

            }
        });
       
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AtackL;
    private javax.swing.JProgressBar Barra1;
    private javax.swing.JProgressBar Barra2;
    private javax.swing.JLabel E1;
    private javax.swing.JLabel E2;
    private javax.swing.JLabel E3;
    private javax.swing.JLabel E4;
    private javax.swing.JLabel E5;
    private javax.swing.JLabel E6;
    private javax.swing.JLabel E7;
    private javax.swing.JLabel E8;
    private javax.swing.JLabel Fondo;
    private javax.swing.JButton HealL;
    private javax.swing.JLabel HealPercent1;
    private javax.swing.JLabel HealPercent2;
    private javax.swing.JLabel P1;
    private javax.swing.JLabel P2;
    private javax.swing.JLabel P3;
    private javax.swing.JLabel P4;
    private javax.swing.JLabel P5;
    private javax.swing.JLabel P6;
    private javax.swing.JLabel Play1Txt;
    private javax.swing.JLabel Play2Txt;
    private javax.swing.JLabel Turno;
    // End of variables declaration//GEN-END:variables
}
