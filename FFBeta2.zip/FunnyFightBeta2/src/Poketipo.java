public class Poketipo {
    
    private int SpecialAtack;
    private String Tipo;

    public Poketipo(int SpecialAtack, String Tipo) {
        this.SpecialAtack = SpecialAtack;
        this.Tipo = Tipo;
    }

    
    
    
    public int getSpecialAtack() {
        return SpecialAtack;
    }

    public void setSpecialAtack(int SpecialAtack) {
        this.SpecialAtack = SpecialAtack;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }
    
    
    
    
}
